-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2+deb7u7
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 30-03-2017 a las 18:02:30
-- Versión del servidor: 5.5.54
-- Versión de PHP: 5.4.45-0+deb7u6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `conectar`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `SubTipoInforme`
--

CREATE TABLE IF NOT EXISTS `SubTipoInforme` (
  `subTipoId` int(4) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `tipoId` int(4) NOT NULL,
  `nombre` varchar(30) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` varchar(100) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `estado` set('Activo','Inactivo') CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL DEFAULT 'Activo',
  `fechaModif` date NOT NULL,
  `userModif` int(4) NOT NULL,
  PRIMARY KEY (`subTipoId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Volcado de datos para la tabla `SubTipoInforme`
--

INSERT INTO `SubTipoInforme` (`subTipoId`, `tipoId`, `nombre`, `descripcion`, `estado`, `fechaModif`, `userModif`) VALUES
(0001, 1, 'asistencia tecnica', 'asistencia tecnica a equipamiento tecnologico', 'Activo', '2017-03-30', 1),
(0002, 3, 'informe tecnico', 'informe de problemas tecnicos del equipamiento tec', 'Activo', '2017-03-30', 1),
(0004, 2, 'visita institucional', 'visita institucional del establecimiento', 'Activo', '2017-03-30', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
